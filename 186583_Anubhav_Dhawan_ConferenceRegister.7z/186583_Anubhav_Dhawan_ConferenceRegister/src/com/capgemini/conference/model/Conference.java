package com.capgemini.conference.model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Conference {

	WebDriver driver;
	
	@FindBy(how = How.NAME, name = "txtFN")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(how = How.NAME, name = "txtLN")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(how = How.NAME, name = "Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(how = How.NAME, name = "Phone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(how = How.NAME, name = "size")
	@CacheLookup
	WebElement num;
	
	@FindBy(how = How.ID, id  = "txtAddress1")
	@CacheLookup
	WebElement building;
	
	@FindBy(how = How.ID, id = "txtAddress2")
	@CacheLookup
	WebElement area;
	
	@FindBy(how = How.NAME, name = "city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how = How.NAME, name = "state")
	@CacheLookup
	WebElement state;
	
	@FindBy(how = How.NAME, name = "memberStatus")
	@CacheLookup
	WebElement status;
	
	@FindBy(how = How.NAME, name = "txtFN")
	@CacheLookup
	WebElement cardHolderName;
	
	@FindBy(how = How.NAME, name = "debit")
	@CacheLookup
	WebElement debitCard;
	
	@FindBy(how = How.NAME, name = "cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(how = How.NAME, name = "month")
	@CacheLookup
	WebElement expMonth;
	
	@FindBy(how = How.NAME, name = "year")
	@CacheLookup
	WebElement expYear;
	
	@FindBy(how=How.ID, id ="btnPayment")
	@CacheLookup
	WebElement submitButton;

	public Conference(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);;
	}

	public WebElement getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num.sendKeys(num);
	}

	public WebElement getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building.sendKeys(building);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status.sendKeys(status);
	}
	
	
	
	public WebElement getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area.sendKeys(area);
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}
	
	public WebElement getDebitCard() {
		return debitCard;
	}

	public void setDebitCard(String debitCard) {
		this.debitCard.sendKeys(debitCard);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public WebElement getExpYear() {
		return expYear;
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}

	public void clickSubmit() {
		this.submitButton.click();
	}
	
}
