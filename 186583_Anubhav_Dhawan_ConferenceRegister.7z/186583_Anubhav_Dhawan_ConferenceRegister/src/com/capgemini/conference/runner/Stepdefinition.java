package com.capgemini.conference.runner;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.conference.model.Conference;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefinition {
	private WebDriver driver;
	private Conference conference;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:/Users/anudhawa/Desktop/driver/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^User is on 'Conference Registration' page$")
	public void user_is_on_Conference_Registration_page() throws Throwable {
		driver.get("C:\\CGWS\\TestWS\\186583_Anubhav_Dhawan_ConferenceRegister\\ConferenceRegistartion.html");
		conference = PageFactory.initElements(driver, Conference.class);
		driver.manage().window().maximize();
	}

	@Then("^Verifying title of the page$")
	public void verifying_title_of_the_page() throws Throwable {
		String expectedMessage = "Conference Registartion";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^No data is Entered in 'FirstName' textbox$")
	public void no_data_is_Entered_in_FirstName_textbox() throws Throwable {
		conference.setFirstName("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the First Name' displays$")
	public void alert_Message_Please_fill_the_First_Name_displays() throws Throwable {
		String expectedMessage = "Please fill the First Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'LastName' textbox$")
	public void no_data_is_Entered_in_LastName_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Last Name' displays$")
	public void alert_Message_Please_fill_the_Last_Name_displays() throws Throwable {
		String expectedMessage = "Please fill the Last Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Email' textbox$")
	public void no_data_is_Entered_in_Email_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Email' displays$")
	public void alert_Message_Please_fill_the_Email_displays() throws Throwable {
		String expectedMessage = "Please fill the Email";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Invalid data is Entered in 'Email' textbox$")
	public void invalid_data_is_Entered_in_Email_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please enter valid Email Id\\.' displays$")
	public void alert_Message_Please_enter_valid_Email_Id_displays() throws Throwable {
		String expectedMessage = "Please enter valid Email Id.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'PhoneNumber' textbox$")
	public void no_data_is_Entered_in_PhoneNumber_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Contact No\\.' displays$")
	public void alert_Message_Please_fill_the_Contact_No_displays() throws Throwable {
		String expectedMessage = "Please fill the Contact No.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Invalid data is Entered in 'PhoneNumber' textbox$")
	public void invalid_data_is_Entered_in_PhoneNumber_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("123456789");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please enter valid Contact no\\.' displays$")
	public void alert_Message_Please_enter_valid_Contact_no_displays() throws Throwable {
		String expectedMessage = "Please enter valid Contact no.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Checkbox 'No of people attending' not clicked$")
	public void checkbox_No_of_people_attending_not_clicked() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Number of people attending' displays$")
	public void alert_Message_Please_fill_the_Number_of_people_attending_displays() throws Throwable {
		String expectedMessage = "Please fill the Number of people attending";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Building Name And Room No' textbox$")
	public void no_data_is_Entered_in_Building_Name_And_Room_No_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Building & Room No' displays$")
	public void alert_Message_Please_fill_the_Building_Room_No_displays() throws Throwable {
		String expectedMessage = "Please fill the Building & Room No";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Area' textbox$")
	public void no_data_is_Entered_in_Area_textbox() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("5190");
		conference.setArea("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please fill the Area name' displays$")
	public void alert_Message_Please_fill_the_Area_name_displays() throws Throwable {
		String expectedMessage = "Please fill the Area name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Checkbox 'City' not clicked$")
	public void checkbox_City_not_clicked() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("5190");
		conference.setArea("this");
		conference.setCity("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please select city' displays$")
	public void alert_Message_Please_select_city_displays() throws Throwable {
		String expectedMessage = "Please select city";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Checkbox 'State' not clicked$")
	public void checkbox_State_not_clicked() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("5190");
		conference.setArea("this");
		conference.setCity("Pune");
		conference.setState("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please select state' displays$")
	public void alert_Message_Please_select_state_displays() throws Throwable {
		String expectedMessage = "Please select state";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Checkbox 'Status' not clicked$")
	public void checkbox_Status_not_clicked() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("5190");
		conference.setArea("this");
		conference.setCity("Pune");
		conference.setState("Tamilnadu");
		conference.setStatus("");
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Please Select MemeberShip status' displays$")
	public void alert_Message_Please_Select_MemeberShip_status_displays() throws Throwable {
		String expectedMessage = "Please Select MemeberShip status";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^All details entered are valid$")
	public void all_details_entered_are_valid() throws Throwable {
		conference.setFirstName("Anubhav");
		conference.setLastName("Dhawan");
		conference.setEmail("abc@gmail.com");
		conference.setPhone("9874563210");
		conference.setNum("1");
		conference.setBuilding("5190");
		conference.setArea("this");
		conference.setCity("Pune");
		conference.setState("Tamilnadu");
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^Alert Message 'Conference Details are validated\\.' displays$")
	public void alert_Message_Conference_Details_are_validated_displays() throws Throwable {
		String expectedMessage = "Conference Details are validated.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		String expectedTitle = "Payment Details";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@Given("^User is on 'PaymentDetails' page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
		driver.get("C:\\CGWS\\TestWS\\186583_Anubhav_Dhawan_ConferenceRegister\\PaymentDetails.html");
		conference = PageFactory.initElements(driver, Conference.class);
		driver.manage().window().maximize();
	}

	@When("^No data is Entered in 'Card Holder Name' textbox$")
	public void no_data_is_Entered_in_Card_Holder_Name_textbox() throws Throwable {
		conference.setCardHolderName("");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Please fill the Card holder name' displays$")
	public void alert_Message_Please_fill_the_Card_holder_name_displays() throws Throwable {
		String expectedMessage = "Please fill the Card holder name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Debit Card Number' textbox$")
	public void no_data_is_Entered_in_Debit_Card_Number_textbox() throws Throwable {
		conference.setCardHolderName("Anubhav");
		conference.setDebitCard("");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Please fill the Debit card Number' displays$")
	public void alert_Message_Please_fill_the_Debit_card_Number_displays() throws Throwable {
		String expectedMessage = "Please fill the Debit card Number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'CVV' textbox$")
	public void no_data_is_Entered_in_CVV_textbox() throws Throwable {
		conference.setCardHolderName("Anubhav");
		conference.setDebitCard("3862000001");
		conference.setCvv("");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Please fill the CVV' displays$")
	public void alert_Message_Please_fill_the_CVV_displays() throws Throwable {
		String expectedMessage = "Please fill the CVV";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Expiration Month' textbox$")
	public void no_data_is_Entered_in_Expiration_Month_textbox() throws Throwable {
		conference.setCardHolderName("Anubhav");
		conference.setDebitCard("3862000001");
		conference.setCvv("213");
		conference.setExpMonth("");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Please fill expiration month' displays$")
	public void alert_Message_Please_fill_expiration_month_displays() throws Throwable {
		String expectedMessage = "Please fill expiration month";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^No data is Entered in 'Expiration Year' textbox$")
	public void no_data_is_Entered_in_Expiration_Year_textbox() throws Throwable {
		conference.setCardHolderName("Anubhav");
		conference.setDebitCard("3862000001");
		conference.setCvv("213");
		conference.setExpMonth("2");
		conference.setExpYear("");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Please fill expiration year' displays$")
	public void alert_Message_Please_fill_expiration_year_displays() throws Throwable {
		String expectedMessage = "Please fill the expiration year";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^All 'PaymentDetails' entered are valid$")
	public void all_PaymentDetails_entered_are_valid() throws Throwable {
		conference.setCardHolderName("Anubhav");
		conference.setDebitCard("3862000001");
		conference.setCvv("213");
		conference.setExpMonth("2");
		conference.setExpYear("2019");
		conference.clickSubmit();
	}

	@Then("^Alert Message 'Conference Room Booking successfully done!!!' displays$")
	public void alert_Message_Conference_Room_Booking_successfully_done_displays() throws Throwable {
		String expectedMessage = "Conference Room Booking successfully done!!!";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}


	
	@After
	public void tearDown() throws Exception {
		driver.switchTo().alert().dismiss();
		driver.quit();
	}

}
