package com.cg.Stepdefination1;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef1 {
	private WebDriver driver;

	@Given("^User is on registration(\\d+) Page$")
	public void user_is_on_registration_Page(int arg1) throws Throwable {
	   driver.get("");
	}

	@Given("^'Welcome to Registration(\\d+)' is the title$")
	public void welcome_to_Registration_is_the_title(int arg1) throws Throwable {
	   	}

	@When("^user is trying to submit data without entering title$")
	public void user_is_trying_to_submit_data_without_entering_title() throws Throwable {
	   
	}

	@Then("^'Select title from the list' alert message should be displayed$")
	public void select_title_from_the_list_alert_message_should_be_displayed() throws Throwable {
	    
	}

	@When("^user is trying to submit data without entering first name$")
	public void user_is_trying_to_submit_data_without_entering_first_name() throws Throwable {
	    
	}

	@Then("^'first Name should not be empty and must have alphabet characters with in the range of (\\d+) to (\\d+)' alert message should be displayed$")
	public void first_Name_should_not_be_empty_and_must_have_alphabet_characters_with_in_the_range_of_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
	    
	}

	@When("^user is trying to submit data without entering last name$")
	public void user_is_trying_to_submit_data_without_entering_last_name() throws Throwable {
	    
	}

	@Then("^'last Name should not be empty and must have alphabet characters with in the range of (\\d+) to (\\d+)' alert message should be displayed$")
	public void last_Name_should_not_be_empty_and_must_have_alphabet_characters_with_in_the_range_of_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
	   
	}

	@When("^user is trying to submit data without entering email$")
	public void user_is_trying_to_submit_data_without_entering_email() throws Throwable {
	   
	}

	@Then("^'Please enter email'alert message should be displayed$")
	public void please_enter_email_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^user is trying to submit data without entering phone number$")
	public void user_is_trying_to_submit_data_without_entering_phone_number() throws Throwable {
	   
	}

	@Then("^'Please enter phone number'alert message should be displayed$")
	public void please_enter_phone_number_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^user is trying to submit data without entering Address$")
	public void user_is_trying_to_submit_data_without_entering_Address() throws Throwable {
	 
	}

	@Then("^'address should not be empty must have alphanumeric characters with in the range of (\\d+) to (\\d+)'alert message should be displayed$")
	public void address_should_not_be_empty_must_have_alphanumeric_characters_with_in_the_range_of_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
	   
	}

	@When("^user is trying to submit data without selecting gender$")
	public void user_is_trying_to_submit_data_without_selecting_gender() throws Throwable {
	    
	}

	@Then("^'please select gender'alert message should be displayed$")
	public void please_select_gender_alert_message_should_be_displayed() throws Throwable {
	    
	}

	@Given("^User is on Registration(\\d+) Page$")
	public void user_is_on_Registration_Page(int arg1) throws Throwable {
	   
	}

	@When("^User is trying to submit data after entring valid set of information$")
	public void user_is_trying_to_submit_data_after_entring_valid_set_of_information() throws Throwable {
	  
	}

	@Then("^'You are Succesfully registered 'alert message should be displayed$")
	public void you_are_Succesfully_registered_alert_message_should_be_displayed() throws Throwable {
	    
	}
}
