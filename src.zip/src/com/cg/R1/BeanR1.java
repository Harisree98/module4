package com.cg.R1;

public class BeanR1 {

}
