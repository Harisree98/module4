package com.capgemini.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import com.capgemini.pom.RegistrationBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * 
 * @author satyadv ClassName=StepDefinition class Date:04-09-2018
 *         Description:StepDefinition class which contains method ,when feature
 *         file is run these methods are generated
 *
 */
public class StepDefinitionRegistration {
	private WebDriver webDriver;
	RegistrationBean bean;
	String pgTitile;

	/**
	 * Method:setUp Despcription:loading webdriver
	 */
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\BDD933\\Registration_186933\\driver\\chromedriver.exe");
		webDriver = new ChromeDriver();
	}

	@Given("^User is on 'Registration Form' Page$")
	public void user_is_on_Registration_Form_Page() throws Throwable {
		webDriver.get("C:\\BDD933\\Registration_186933\\WebPages-BDD MPT\\RegistrationForm.html");

		bean = new RegistrationBean(webDriver);
	}

	@Then("^'Verifying the title of page'$")
	public void verifying_the_title_of_page() throws Throwable {
		String expectedMessage = "";
		String actualMessage = webDriver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		webDriver.close();
	}

	@When("^User enters invalid User Id$")
	public void user_enters_invalid_User_Id() throws Throwable {
		bean.setUserId("s");
		bean.setSubmitRequest();
	}

	@Then("^displays 'User Id should not be empty/length be between (\\d+) to (\\d+)'$")
	public void displays_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectedMessage = "User Id should not be empty / length be between 5 to 12";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters invalid Password$")
	public void user_enters_invalid_Password() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("s ");
		bean.setSubmitRequest();
	}

	@Then("^displays 'Password should not be empty/length be between (\\d+) to (\\d+)'$")
	public void displays_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectedMessage = "Password should not be empty / length be between 7 to 12";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters invalid  Name$")
	public void user_enters_invalid_Name() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("");
		bean.setSubmitRequest();
	}

	@Then("^displays 'name should not be empty and must have alphabet characters only'$")
	public void displays_name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String expectedMessage = "Name should not be empty and must have alphabet characters only";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters address$")
	public void user_enters_address() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("<?");
		bean.setSubmitRequest();
	}

	@Then("^displays 'User address must have alphanumeric characters only'$")
	public void displays_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String expectedMessage = "User address must have alphanumeric characters only";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters Invalid Country Preference$")
	public void user_enters_Invalid_Country_Preference() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("kakinada");
		bean.setCountry("");
		bean.setSubmitRequest();
	}

	@Then("^displays 'Select your country from the list'$")
	public void displays_Select_your_country_from_the_list() throws Throwable {
		String expectedMessage = "Select your country from the list";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters Invalid Zip Code$")
	public void user_enters_Invalid_Zip_Code() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("kakinada");
		bean.setCountry("AF");
		bean.setZip("abcd");
		bean.setSubmitRequest();
	}

	@Then("^displays 'Zip code must have numeric characyters only'$")
	public void displays_Zip_code_must_have_numeric_characyters_only() throws Throwable {
		String expectedMessage = "ZIP code must have numeric characters only";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("kakinada");
		bean.setCountry("AF");
		bean.setZip("7897");
		bean.setEmail("ajhjkhjh");
		bean.setSubmitRequest();
	}

	@Then("^displays 'you have entered an invalid email address!'$")
	public void displays_you_have_entered_an_invalid_email_address() throws Throwable {
		String expectedMessage = "You have entered an invalid email address!";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User enters Invalid gender$")
	public void user_enters_Invalid_gender() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("kakinada");
		bean.setCountry("AF");
		bean.setZip("7897");
		bean.setEmail("satya@gmail.com");
		bean.setGender("");
		bean.setSubmitRequest();
	}

	@Then("^displays 'Please select gender'$")
	public void displays_Please_select_gender() throws Throwable {
		String expectedMessage = "Please Select gender";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

	@When("^User clicks 'Submit Your Request' button$")
	public void user_clicks_Submit_Your_Request_button() throws Throwable {
		bean.setUserId("satya");
		bean.setPass("satya@123");
		bean.setName("SatyaDevi");
		bean.setAddress("kakinada");
		bean.setCountry("AF");
		bean.setZip("7897");
		bean.setEmail("satya@gmail.com");
		bean.setGender("Female");

		bean.setSubmitRequest();
	}

	@Then("^displays 'Succesfully registered'$")
	public void displays_Succesfully_registered() throws Throwable {
		String expectedMessage = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualMessage = webDriver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		webDriver.switchTo().alert().accept();
		webDriver.close();
	}

}
