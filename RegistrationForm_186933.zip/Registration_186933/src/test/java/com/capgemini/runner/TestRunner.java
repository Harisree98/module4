package com.capgemini.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
/**
 * 
 * @author satyadv
 * ClassName=TestRunner
 * Date:11-09-2019
 * Description:This class is the runner class from where we run the project
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features="C:\\BDD933\\Registration_186933\\Feature\\registration.feature",dryRun=false,glue="com.capgemini.stepdefinition")
public class TestRunner {

}
