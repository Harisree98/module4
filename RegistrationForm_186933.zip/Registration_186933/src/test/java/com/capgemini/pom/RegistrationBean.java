package com.capgemini.pom;

import static org.junit.Assert.assertEquals;




import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
/***
 * 
 * @author satyadv
 * ClassName:Coaching bean class
 * Date-11-09-2019
 * Description:It is Page Object Model
 *
 */

public class RegistrationBean {
	private WebDriver driver;
	
	@FindBy(how=How.NAME,using="userid")
	@CacheLookup
	WebElement userId;
	
	@FindBy(how=How.NAME,using="passid")
	@CacheLookup
	WebElement pass;
	
	@FindBy(how=How.NAME,using="username")
	@CacheLookup
	WebElement name;
	
	@FindBy(how=How.NAME,using="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(xpath="/html/body/form/ul/li[10]/select")
	
	WebElement country;
	
	@FindBy(how=How.NAME,using="zip")
	@CacheLookup
	WebElement zip;
	@FindBy(how=How.NAME,using="email")
	@CacheLookup
	WebElement email;
	
	@FindBy(css = "input[value='Male']")
	WebElement gender_male;

	@FindBy(css = "input[value='Female']")
	WebElement gender_female;
	
	@FindBy(css = "input[value='noen']")
	WebElement lang_noen;

	@FindBy(css = "input[value='en']")
	WebElement lang_en;
	@FindBy(how=How.NAME, using="submit")
	@CacheLookup
	WebElement submitRequest;
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}
	public WebElement getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass .sendKeys( pass);
	}
	public WebElement getName() {
		return name;
	}
	public void setName(String name) {
		this.name.sendKeys( name);
	}
	public WebElement getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address. sendKeys(address);
	}
	public WebElement getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country.sendKeys(country);;
	}
	public WebElement getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip.sendKeys(zip);;
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	

	public void setGender(String sex)
	{
		sex = sex.toLowerCase();
		if(sex.equals("male"))
			this.gender_male.click();
		if(sex.equals("female"))
			this.gender_female.click();
	}

	public WebElement getLang_noen() {
		return lang_noen;
	}
	
	public WebElement getLang_en() {
		return lang_en;
	}
	public void setLanguage(String lang)
	{
		lang = lang.toLowerCase();
		if(lang.equals("non english"))
		{
			this.lang_en.click();
			this.lang_noen.click();
		}
		
	}
	public WebElement getSubmitRequest() {
		return submitRequest;
	}
	public void setSubmitRequest() {
		this.submitRequest.click();
	}
	
	public RegistrationBean(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
